<p style="text-align:center"><img src="http://labimg-labimg.stor.sinaapp.com/original/51de1867c13df9348e0d062c49e25d14.png" /></p>

这是一款简洁小清新主题，代码托管于此，欢迎fork或star。主题目前只有Typecho版，希望各界高手能帮忙移植到WordPress和EMLOG等博客平台，万分感谢。

详细的介绍及注意事项请看[发布页面](http://ben-lab.com/typecho/1805.html)。