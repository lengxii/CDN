<?php
/*
Plugin Name: Qvod快播,百度影音代码插入插件
Description: 这是把原来繁琐的代码插入换成了按钮操作,这样就减少了插入的错误,同样也增加了用户增加文章的速度
Version: 1.0
Author: 小寂
Author URI: http://www.isays.cn
 */
function add_qvod_button(){
?>
 <script type="text/javascript">
	QTags.addButton('qvod', 'qvod','<div id="qvod" style="width:100%px;height:450px;overflow:hidden;margin:0 auto;"><object classid="clsid:F3D0D36F-23F8-4682-A195-74C92B03D4AF" width="100%" height="450" id="QvodPlayer" name="QvodPlayer" onerror="document.getElementById(\'QvodPlayer\').style.display=\'none\';document.getElementById(\'iframe_down\').style.display=\'\';document.getElementById(\'iframe_down\').src=\'http://error2.qvod.com/error4.htm\';"> <param name=\'Showcontrol\' value=\'1\'> <param name=\'URL\' value=\'快播种子地址\'><param name=\'Autoplay\' value=\'1\'><embed id="QvodPlayer2" name="QvodPlayer2" width="100%" height="450" URL=\'快播种子地址|\' type=\'application/qvod-plugin\' Autoplay=\'1\' ></embed></object></div><div class="qvodplayer_gg">本电影采集自网络，本站并不参与录制和制作，仅提供QVOD观看地址，如您喜欢或想收藏本电影，推荐您到电影院观看正版碟。</div>');		
	QTags.addButton('BDPlayer', 'BDPlayer', '<\/script></div><div id="dbplayer" style="width:600px;height:500px;overflow:hidden;margin:0 auto;"><script language="javascript">var BdPlayer = new Array();BdPlayer[\'time\'] = 0;BdPlayer[\'buffer\'] = \'\';BdPlayer[\'pause\'] = \'\';BdPlayer[\'end\'] = \'\';BdPlayer[\'tn\'] = \'12345678\';BdPlayer[\'width\'] = 600;BdPlayer[\'height\'] = 480;BdPlayer[\'showclient\'] = 1;BdPlayer[\'url\'] = \'插入要插入的视频地址\';BdPlayer[\'nextcacheurl\'] = \'\';BdPlayer[\'lastwebpage\'] = \'\';BdPlayer[\'nextwebpage\'] = \'\';<\/script><script language="javascript" src="http://php.player.baidu.com/bdplayer/player.js" charset="utf-8"><\/script></div>');
 </script>
<?php
}
add_action('admin_print_footer_scripts', 'add_qvod_button');

?>
